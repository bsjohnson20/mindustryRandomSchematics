const reCC = extendContent(CommandCenter, "reinforced-command-center", {
});
reCC.flags = EnumSet.of(BlockFlag.rally);