# Contributing

How can I contribute to this mod?

  You can contribute to this mod by doing the following:
    
    - Leave your suggestion in the Discord
    - Leave your suggestion in the Issues tab here on Github
    - Fork this repository and create a pull request

What happens if my suggestion makes it into the mod?
  
  Depending on the size of your suggestion:
  
    - Small suggestion: It will just be added and there will be no credit. 
      It will just be there.
      
    - Large suggestion/help: It will be added and you will get a mention on
      Discord via something like a role or you will even be mentioned in the 
      mod.hjson
      
To everyone who contributed until now: Thank you very much!

Every contribution helps to make this mod better and more 
enjoyable for everyone!
