
const { ambientMusic : music } = Vars.control.sound;

music.add(loadMusic('mysterious-world'));
music.add(loadMusic('impending-doom'));
