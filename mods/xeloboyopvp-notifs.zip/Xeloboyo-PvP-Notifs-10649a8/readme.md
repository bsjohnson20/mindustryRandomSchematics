Mod functions:
  - Enemy tech tree/ production alerts <br>
  ![](https://media.discordapp.net/attachments/745425090459467917/797833541584814097/unknown.png)<br>
  ![](https://media.discordapp.net/attachments/745425090459467917/797833153037074452/unknown.png)<br>
  - Quick schematics <br>
 ![d144](https://user-images.githubusercontent.com/13158938/109777777-30a4b900-7c58-11eb-8cbf-c2e517562464.gif)<br>
  - See ranges<br>
  ![](https://media.discordapp.net/attachments/745425090459467917/799143750902349854/unknown.png)<br>
  - afk poly/mono AI<br>
  ![image](https://user-images.githubusercontent.com/13158938/109778001-6cd81980-7c58-11eb-8a98-8bbe8aea80ae.png)<br>
  - global power status <br>
  ![e](https://media.discordapp.net/attachments/745425090459467917/800621278850580500/unknown.png)<br>
  - Factory status<br>
  ![image](https://user-images.githubusercontent.com/13158938/109778244-b294e200-7c58-11eb-9c54-8c302cff0489.png)<br>
  - Damage alerts<br>
  ![image](https://user-images.githubusercontent.com/13158938/109778430-e96af800-7c58-11eb-951d-ba5407cd405f.png)<br>
  - See ores under blocks<br>
  ![image](https://user-images.githubusercontent.com/13158938/109778690-38b12880-7c59-11eb-90fb-424335851b3b.png)<br>
  
 And others
 
  - Disable lighting<br>
  
  - Count all units<br>
  
  - Quick vote kick and sync<br>
  
  - Disable lighting<br>
  
