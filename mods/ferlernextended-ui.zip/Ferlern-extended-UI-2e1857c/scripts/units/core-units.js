module.exports = [
    'alpha', 'beta', 'gamma'
]
