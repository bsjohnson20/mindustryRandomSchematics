module.exports = [
    'mono', 'poly', 'mega'
]
