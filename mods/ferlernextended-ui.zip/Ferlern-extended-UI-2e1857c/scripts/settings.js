// Bars
exports.factoryProgressBarSize = 4;
exports.unitBarSize = 4;

exports.unitBarDisplayTime = 5000;
exports.unitBarFadeTime = 3000;
