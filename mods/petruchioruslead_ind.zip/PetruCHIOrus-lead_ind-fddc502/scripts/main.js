var mod = Vars.mods.locateMod("lead_ind");
mod.meta.displayName = "[white]Lead Industri[pink]es";
mod.meta.description = "[pink]New guns, drills, crafting, materials and resourses";
mod.meta.author = "[white]Petru[#C7ACB4]CHIO[white]rus\n[white]Defense[red]X\n[#7933B3]paulieg626";